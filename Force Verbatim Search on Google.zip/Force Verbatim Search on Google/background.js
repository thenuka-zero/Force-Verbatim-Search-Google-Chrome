chrome.webNavigation.onCompleted.addListener(
  function(details) {
    // Only run on Google search results pages
    if (details.url.includes("google.com/search?")) {
      const url = new URL(details.url);
      
      // Don't modify if already in verbatim mode
      if (!url.searchParams.has("tbs")) {
        // Add verbatim mode parameter
        url.searchParams.set("tbs", "li:1");
        
        // Update the URL
        chrome.tabs.update(details.tabId, {
          url: url.toString()
        });
      }
    }
  },
  {
    url: [{
      hostContains: "google.com",
      pathContains: "search"
    }]
  }
);